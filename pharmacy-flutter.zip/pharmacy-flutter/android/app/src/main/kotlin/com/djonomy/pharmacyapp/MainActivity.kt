package com.djonomy.pharmacyapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
