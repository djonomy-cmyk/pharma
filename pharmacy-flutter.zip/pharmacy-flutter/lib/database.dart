import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import 'models.dart';

class DB {
  static Database? _db;

  static Future<Database> get database async {
    _db ??= await _init();
    return _db!;
  }

  static Future<Database> _init() async {
    final path = join(await getDatabasesPath(), 'pharmacy_v1.db');
    return openDatabase(path, version: 1, onCreate: _create);
  }

  static Future<void> _create(Database db, int v) async {
    await db.execute('''
      CREATE TABLE customers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        phone TEXT DEFAULT '',
        address TEXT DEFAULT '',
        notes TEXT DEFAULT '',
        created_at TEXT DEFAULT (datetime('now','localtime'))
      )
    ''');
    await db.execute('''
      CREATE TABLE disease_categories (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        description TEXT DEFAULT ''
      )
    ''');
    await db.execute('''
      CREATE TABLE medicine_types (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL
      )
    ''');
    await db.execute('''
      CREATE TABLE medicines (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        category_id INTEGER,
        type_id INTEGER,
        buy_price REAL DEFAULT 0,
        sell_price REAL DEFAULT 0,
        stock INTEGER DEFAULT 0,
        min_stock INTEGER DEFAULT 5,
        unit TEXT DEFAULT 'علبة',
        description TEXT DEFAULT ''
      )
    ''');
    await db.execute('''
      CREATE TABLE debt_transactions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        customer_id INTEGER NOT NULL,
        medicine_id INTEGER,
        medicine_name TEXT DEFAULT '',
        quantity REAL DEFAULT 1,
        unit_price REAL DEFAULT 0,
        total_amount REAL DEFAULT 0,
        date TEXT DEFAULT (datetime('now','localtime')),
        notes TEXT DEFAULT ''
      )
    ''');
    await db.execute('''
      CREATE TABLE payments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        customer_id INTEGER NOT NULL,
        amount REAL DEFAULT 0,
        date TEXT DEFAULT (datetime('now','localtime')),
        notes TEXT DEFAULT ''
      )
    ''');
    await _insertDefaults(db);
  }

  static Future<void> _insertDefaults(Database db) async {
    final cats = [
      ['أمراض القلب والأوعية الدموية', 'ضغط الدم، الذبحة الصدرية'],
      ['أمراض السكري', 'أنسولين، متحكمات سكر الدم'],
      ['أمراض الجهاز الهضمي', 'المعدة، الأمعاء، الكبد'],
      ['أمراض الجهاز التنفسي', 'الربو، السعال، الشعب الهوائية'],
      ['أمراض المفاصل والعظام', 'الروماتيزم، هشاشة العظام'],
      ['أمراض الجهاز العصبي', 'الصرع، الصداع النصفي'],
      ['أمراض الجلد', 'الأكزيما، الصدفية، الحساسية'],
      ['أمراض العيون والأنف والأذن', 'قطرات، التهابات'],
      ['فيتامينات ومكملات غذائية', 'تقوية المناعة، كالسيوم'],
      ['أمراض الغدة الدرقية', 'ميزانين، ديتيروكسين'],
      ['أمراض الكلى والمسالك', 'التهابات مسالك، حصى الكلى'],
      ['أمراض الأطفال', 'أدوية مخصصة للأطفال'],
    ];
    for (final c in cats) {
      await db.insert('disease_categories', {'name': c[0], 'description': c[1]});
    }
    final types = [
      'مضاد حيوي', 'مضاد التهاب', 'مسكن ألم', 'مكمل غذائي',
      'مضاد فطريات', 'مضاد فيروسات', 'خافض ضغط الدم', 'منظم سكر الدم',
      'مضاد حساسية', 'مهدئ ومنوم', 'ملين', 'مضاد إسهال',
      'شراب', 'قطرات', 'حقنة', 'مرهم / كريم', 'بخاخ', 'لصقة طبية',
    ];
    for (final t in types) {
      await db.insert('medicine_types', {'name': t});
    }
  }

  // ── CUSTOMERS ──────────────────────────────────────
  static Future<List<Customer>> getCustomers() async {
    final db = await database;
    final rows = await db.rawQuery('''
      SELECT c.*,
        COALESCE((SELECT SUM(dt.total_amount) FROM debt_transactions dt WHERE dt.customer_id=c.id),0) as total_debt,
        COALESCE((SELECT SUM(p.amount) FROM payments p WHERE p.customer_id=c.id),0) as total_paid
      FROM customers c ORDER BY c.name ASC
    ''');
    return rows.map(Customer.fromMap).toList();
  }

  static Future<Customer?> getCustomer(int id) async {
    final db = await database;
    final rows = await db.rawQuery('''
      SELECT c.*,
        COALESCE((SELECT SUM(dt.total_amount) FROM debt_transactions dt WHERE dt.customer_id=c.id),0) as total_debt,
        COALESCE((SELECT SUM(p.amount) FROM payments p WHERE p.customer_id=c.id),0) as total_paid
      FROM customers c WHERE c.id=?
    ''', [id]);
    if (rows.isEmpty) return null;
    return Customer.fromMap(rows.first);
  }

  static Future<int> addCustomer(Customer c) async {
    final db = await database;
    return db.insert('customers', c.toMap());
  }

  static Future<void> updateCustomer(Customer c) async {
    final db = await database;
    await db.update('customers', c.toMap(), where: 'id=?', whereArgs: [c.id]);
  }

  static Future<void> deleteCustomer(int id) async {
    final db = await database;
    await db.delete('debt_transactions', where: 'customer_id=?', whereArgs: [id]);
    await db.delete('payments', where: 'customer_id=?', whereArgs: [id]);
    await db.delete('customers', where: 'id=?', whereArgs: [id]);
  }

  // ── DEBT TRANSACTIONS ──────────────────────────────
  static Future<List<DebtTransaction>> getDebts(int customerId) async {
    final db = await database;
    final rows = await db.query('debt_transactions',
        where: 'customer_id=?', whereArgs: [customerId], orderBy: 'date DESC');
    return rows.map(DebtTransaction.fromMap).toList();
  }

  static Future<int> addDebt(DebtTransaction d, {bool updateStock = false}) async {
    final db = await database;
    final id = await db.insert('debt_transactions', d.toMap());
    if (updateStock && d.medicineId != null) {
      await db.rawUpdate(
          'UPDATE medicines SET stock=stock-? WHERE id=?', [d.quantity, d.medicineId]);
    }
    return id;
  }

  static Future<void> deleteDebt(int id) async {
    final db = await database;
    await db.delete('debt_transactions', where: 'id=?', whereArgs: [id]);
  }

  // ── PAYMENTS ───────────────────────────────────────
  static Future<List<Payment>> getPayments(int customerId) async {
    final db = await database;
    final rows = await db.query('payments',
        where: 'customer_id=?', whereArgs: [customerId], orderBy: 'date DESC');
    return rows.map(Payment.fromMap).toList();
  }

  static Future<void> addPayment(Payment p) async {
    final db = await database;
    await db.insert('payments', p.toMap());
  }

  // ── MEDICINES ──────────────────────────────────────
  static Future<List<Medicine>> getMedicines() async {
    final db = await database;
    final rows = await db.rawQuery('''
      SELECT m.*, dc.name as category_name, mt.name as type_name
      FROM medicines m
      LEFT JOIN disease_categories dc ON m.category_id=dc.id
      LEFT JOIN medicine_types mt ON m.type_id=mt.id
      ORDER BY m.name ASC
    ''');
    return rows.map(Medicine.fromMap).toList();
  }

  static Future<List<Medicine>> getLowStockMedicines() async {
    final db = await database;
    final rows = await db.rawQuery(
        'SELECT * FROM medicines WHERE stock<=min_stock ORDER BY stock ASC');
    return rows.map(Medicine.fromMap).toList();
  }

  static Future<int> addMedicine(Medicine m) async {
    final db = await database;
    return db.insert('medicines', m.toMap());
  }

  static Future<void> updateMedicine(Medicine m) async {
    final db = await database;
    await db.update('medicines', m.toMap(), where: 'id=?', whereArgs: [m.id]);
  }

  static Future<void> deleteMedicine(int id) async {
    final db = await database;
    await db.delete('medicines', where: 'id=?', whereArgs: [id]);
  }

  // ── CATEGORIES ─────────────────────────────────────
  static Future<List<DiseaseCategory>> getCategories() async {
    final db = await database;
    final rows = await db.query('disease_categories', orderBy: 'name ASC');
    return rows.map(DiseaseCategory.fromMap).toList();
  }

  static Future<void> addCategory(DiseaseCategory c) async {
    final db = await database;
    await db.insert('disease_categories', c.toMap());
  }

  static Future<void> updateCategory(DiseaseCategory c) async {
    final db = await database;
    await db.update('disease_categories', c.toMap(), where: 'id=?', whereArgs: [c.id]);
  }

  static Future<void> deleteCategory(int id) async {
    final db = await database;
    await db.delete('disease_categories', where: 'id=?', whereArgs: [id]);
  }

  // ── MEDICINE TYPES ─────────────────────────────────
  static Future<List<MedicineType>> getMedicineTypes() async {
    final db = await database;
    final rows = await db.query('medicine_types', orderBy: 'name ASC');
    return rows.map(MedicineType.fromMap).toList();
  }

  static Future<void> addMedicineType(MedicineType t) async {
    final db = await database;
    await db.insert('medicine_types', t.toMap());
  }

  static Future<void> updateMedicineType(MedicineType t) async {
    final db = await database;
    await db.update('medicine_types', t.toMap(), where: 'id=?', whereArgs: [t.id]);
  }

  static Future<void> deleteMedicineType(int id) async {
    final db = await database;
    await db.delete('medicine_types', where: 'id=?', whereArgs: [id]);
  }

  // ── DASHBOARD ──────────────────────────────────────
  static Future<DashboardStats> getStats() async {
    final db = await database;
    final cust = await db.rawQuery('SELECT COUNT(*) as v FROM customers');
    final debt = await db.rawQuery('SELECT COALESCE(SUM(total_amount),0) as v FROM debt_transactions');
    final paid = await db.rawQuery('SELECT COALESCE(SUM(amount),0) as v FROM payments');
    final low  = await db.rawQuery('SELECT COUNT(*) as v FROM medicines WHERE stock<=min_stock');
    final meds = await db.rawQuery('SELECT COUNT(*) as v FROM medicines');
    return DashboardStats(
      totalCustomers: cust.first['v'] as int,
      totalDebt: (debt.first['v'] as num).toDouble(),
      totalPaid: (paid.first['v'] as num).toDouble(),
      lowStockCount: low.first['v'] as int,
      totalMedicines: meds.first['v'] as int,
    );
  }

  static Future<List<Customer>> getTopDebtors({int limit = 5}) async {
    final db = await database;
    final rows = await db.rawQuery('''
      SELECT c.id, c.name, c.phone,
        COALESCE((SELECT SUM(dt.total_amount) FROM debt_transactions dt WHERE dt.customer_id=c.id),0) as total_debt,
        COALESCE((SELECT SUM(p.amount) FROM payments p WHERE p.customer_id=c.id),0) as total_paid
      FROM customers c
      GROUP BY c.id
      HAVING (total_debt-total_paid)>0
      ORDER BY (total_debt-total_paid) DESC
      LIMIT ?
    ''', [limit]);
    return rows.map(Customer.fromMap).toList();
  }
}
