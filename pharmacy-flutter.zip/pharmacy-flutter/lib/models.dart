// ═══════════════════════════════════════════
//  MODELS
// ═══════════════════════════════════════════

class Customer {
  final int? id;
  final String name;
  final String phone;
  final String address;
  final String notes;
  final String createdAt;
  final double totalDebt;
  final double totalPaid;

  Customer({
    this.id,
    required this.name,
    this.phone = '',
    this.address = '',
    this.notes = '',
    this.createdAt = '',
    this.totalDebt = 0,
    this.totalPaid = 0,
  });

  double get remainingDebt => totalDebt - totalPaid;

  Map<String, dynamic> toMap() => {
    if (id != null) 'id': id,
    'name': name,
    'phone': phone,
    'address': address,
    'notes': notes,
  };

  factory Customer.fromMap(Map<String, dynamic> m) => Customer(
    id: m['id'],
    name: m['name'] ?? '',
    phone: m['phone'] ?? '',
    address: m['address'] ?? '',
    notes: m['notes'] ?? '',
    createdAt: m['created_at'] ?? '',
    totalDebt: (m['total_debt'] ?? 0).toDouble(),
    totalPaid: (m['total_paid'] ?? 0).toDouble(),
  );
}

class DebtTransaction {
  final int? id;
  final int customerId;
  final int? medicineId;
  final String medicineName;
  final double quantity;
  final double unitPrice;
  final double totalAmount;
  final String date;
  final String notes;

  DebtTransaction({
    this.id,
    required this.customerId,
    this.medicineId,
    required this.medicineName,
    required this.quantity,
    required this.unitPrice,
    required this.totalAmount,
    this.date = '',
    this.notes = '',
  });

  Map<String, dynamic> toMap() => {
    if (id != null) 'id': id,
    'customer_id': customerId,
    'medicine_id': medicineId,
    'medicine_name': medicineName,
    'quantity': quantity,
    'unit_price': unitPrice,
    'total_amount': totalAmount,
    'notes': notes,
  };

  factory DebtTransaction.fromMap(Map<String, dynamic> m) => DebtTransaction(
    id: m['id'],
    customerId: m['customer_id'],
    medicineId: m['medicine_id'],
    medicineName: m['medicine_name'] ?? '',
    quantity: (m['quantity'] ?? 1).toDouble(),
    unitPrice: (m['unit_price'] ?? 0).toDouble(),
    totalAmount: (m['total_amount'] ?? 0).toDouble(),
    date: m['date'] ?? '',
    notes: m['notes'] ?? '',
  );
}

class Payment {
  final int? id;
  final int customerId;
  final double amount;
  final String date;
  final String notes;

  Payment({
    this.id,
    required this.customerId,
    required this.amount,
    this.date = '',
    this.notes = '',
  });

  Map<String, dynamic> toMap() => {
    if (id != null) 'id': id,
    'customer_id': customerId,
    'amount': amount,
    'notes': notes,
  };

  factory Payment.fromMap(Map<String, dynamic> m) => Payment(
    id: m['id'],
    customerId: m['customer_id'],
    amount: (m['amount'] ?? 0).toDouble(),
    date: m['date'] ?? '',
    notes: m['notes'] ?? '',
  );
}

class Medicine {
  final int? id;
  final String name;
  final int? categoryId;
  final int? typeId;
  final double buyPrice;
  final double sellPrice;
  final int stock;
  final int minStock;
  final String unit;
  final String description;
  final String categoryName;
  final String typeName;

  Medicine({
    this.id,
    required this.name,
    this.categoryId,
    this.typeId,
    this.buyPrice = 0,
    this.sellPrice = 0,
    this.stock = 0,
    this.minStock = 5,
    this.unit = 'علبة',
    this.description = '',
    this.categoryName = '',
    this.typeName = '',
  });

  bool get isLowStock => stock <= minStock;
  bool get isOutOfStock => stock == 0;

  Map<String, dynamic> toMap() => {
    if (id != null) 'id': id,
    'name': name,
    'category_id': categoryId,
    'type_id': typeId,
    'buy_price': buyPrice,
    'sell_price': sellPrice,
    'stock': stock,
    'min_stock': minStock,
    'unit': unit,
    'description': description,
  };

  factory Medicine.fromMap(Map<String, dynamic> m) => Medicine(
    id: m['id'],
    name: m['name'] ?? '',
    categoryId: m['category_id'],
    typeId: m['type_id'],
    buyPrice: (m['buy_price'] ?? 0).toDouble(),
    sellPrice: (m['sell_price'] ?? 0).toDouble(),
    stock: m['stock'] ?? 0,
    minStock: m['min_stock'] ?? 5,
    unit: m['unit'] ?? 'علبة',
    description: m['description'] ?? '',
    categoryName: m['category_name'] ?? '',
    typeName: m['type_name'] ?? '',
  );
}

class DiseaseCategory {
  final int? id;
  final String name;
  final String description;

  DiseaseCategory({this.id, required this.name, this.description = ''});

  Map<String, dynamic> toMap() => {
    if (id != null) 'id': id,
    'name': name,
    'description': description,
  };

  factory DiseaseCategory.fromMap(Map<String, dynamic> m) => DiseaseCategory(
    id: m['id'],
    name: m['name'] ?? '',
    description: m['description'] ?? '',
  );
}

class MedicineType {
  final int? id;
  final String name;

  MedicineType({this.id, required this.name});

  Map<String, dynamic> toMap() => {
    if (id != null) 'id': id,
    'name': name,
  };

  factory MedicineType.fromMap(Map<String, dynamic> m) => MedicineType(
    id: m['id'],
    name: m['name'] ?? '',
  );
}

class DashboardStats {
  final int totalCustomers;
  final double totalDebt;
  final double totalPaid;
  final int lowStockCount;
  final int totalMedicines;

  DashboardStats({
    this.totalCustomers = 0,
    this.totalDebt = 0,
    this.totalPaid = 0,
    this.lowStockCount = 0,
    this.totalMedicines = 0,
  });

  double get remainingDebt => totalDebt - totalPaid;
  int get paymentPercent => totalDebt > 0
      ? ((totalPaid / totalDebt) * 100).round().clamp(0, 100)
      : 0;
}
