import 'package:flutter/material.dart';
import '../main.dart';
import '../database.dart';
import '../models.dart';

// ═══════════════════════════════════════════
//  CATEGORIES SCREEN (تصنيفات الأمراض)
// ═══════════════════════════════════════════
class CategoriesScreen extends StatefulWidget {
  const CategoriesScreen({super.key});
  @override State<CategoriesScreen> createState() => _CategoriesScreenState();
}

class _CategoriesScreenState extends State<CategoriesScreen> {
  List<DiseaseCategory> _all = [], _shown = [];
  final _search = TextEditingController();

  @override void initState() { super.initState(); _load(); }
  @override void didChangeDependencies() { super.didChangeDependencies(); _load(); }

  Future<void> _load() async {
    final d = await DB.getCategories();
    if (mounted) setState(() { _all = d; _apply(); });
  }

  void _apply() {
    final q = _search.text;
    setState(() => _shown = q.isEmpty
        ? List.from(_all)
        : _all.where((c) => c.name.contains(q) || c.description.contains(q)).toList());
  }

  void _openForm({DiseaseCategory? cat}) {
    final nameCtrl = TextEditingController(text: cat?.name ?? '');
    final descCtrl = TextEditingController(text: cat?.description ?? '');
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (_) => Padding(
        padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom, left: 16, right: 16, top: 16),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Container(width: 40, height: 4, decoration: BoxDecoration(color: Colors.grey[300], borderRadius: BorderRadius.circular(2))),
          const SizedBox(height: 12),
          Text(cat == null ? 'إضافة تصنيف جديد' : 'تعديل التصنيف',
              style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: kPrimary)),
          const SizedBox(height: 14),
          TextField(controller: nameCtrl, textDirection: TextDirection.rtl,
            decoration: const InputDecoration(labelText: 'اسم التصنيف *', prefixIcon: Icon(Icons.category))),
          const SizedBox(height: 10),
          TextField(controller: descCtrl, textDirection: TextDirection.rtl, maxLines: 2,
            decoration: const InputDecoration(labelText: 'الوصف والأمثلة', prefixIcon: Icon(Icons.notes))),
          const SizedBox(height: 14),
          SizedBox(width: double.infinity, child: ElevatedButton.icon(
            icon: const Icon(Icons.save),
            label: Text(cat == null ? 'إضافة' : 'حفظ التعديلات'),
            onPressed: () async {
              if (nameCtrl.text.trim().isEmpty) return;
              final c = DiseaseCategory(id: cat?.id, name: nameCtrl.text.trim(), description: descCtrl.text.trim());
              if (cat == null) await DB.addCategory(c);
              else await DB.updateCategory(c);
              if (context.mounted) Navigator.pop(context);
              _load();
            },
          )),
          const SizedBox(height: 16),
        ]),
      ),
    );
  }

  Future<void> _delete(DiseaseCategory c) async {
    final ok = await showDialog<bool>(context: context, builder: (_) => AlertDialog(
      title: const Text('حذف التصنيف'),
      content: Text('حذف "${c.name}"؟'),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('إلغاء')),
        TextButton(onPressed: () => Navigator.pop(context, true),
            child: const Text('حذف', style: TextStyle(color: kDanger))),
      ],
    ));
    if (ok == true) { await DB.deleteCategory(c.id!); _load(); }
  }

  final _icons = ['🫀','🩺','🍽️','🌬️','🦴','🧠','🩹','👁️','💊','🩸','🫁','👶','💉','🌡️'];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBg,
      appBar: AppBar(title: const Text('التصنيفات')),
      body: Column(children: [
        // زر انتقال لأنواع الأدوية
        GestureDetector(
          onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const MedicineTypesScreen())),
          child: Container(
            margin: const EdgeInsets.all(12),
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            decoration: BoxDecoration(
              color: kLightGreen, borderRadius: BorderRadius.circular(12),
              border: Border.all(color: kAccent),
            ),
            child: const Row(children: [
              Icon(Icons.arrow_back_ios, size: 14, color: kPrimary),
              Spacer(),
              Text('إدارة أنواع الأدوية', style: TextStyle(fontWeight: FontWeight.bold, color: kPrimary, fontSize: 14)),
              SizedBox(width: 8),
              Icon(Icons.science, color: kPrimary),
            ]),
          ),
        ),
        // رأس
        Padding(padding: const EdgeInsets.symmetric(horizontal: 12),
          child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            CircleAvatar(radius: 18, backgroundColor: kPrimary,
              child: IconButton(padding: EdgeInsets.zero, icon: const Icon(Icons.add, color: Colors.white, size: 20), onPressed: () => _openForm())),
            Text('تصنيفات الأمراض (${_all.length})',
                style: const TextStyle(fontWeight: FontWeight.bold, color: kPrimary, fontSize: 15)),
          ]),
        ),
        const SizedBox(height: 8),
        // بحث
        Padding(padding: const EdgeInsets.symmetric(horizontal: 12),
          child: TextField(controller: _search, onChanged: (_) => _apply(), textDirection: TextDirection.rtl,
            decoration: InputDecoration(
              hintText: 'بحث في التصنيفات...',
              prefixIcon: const Icon(Icons.search),
              filled: true, fillColor: Colors.white,
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide.none),
              contentPadding: const EdgeInsets.symmetric(vertical: 10),
            ),
          ),
        ),
        const SizedBox(height: 8),
        // قائمة
        Expanded(child: RefreshIndicator(onRefresh: _load,
          child: _shown.isEmpty
              ? const Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                  Text('🗂️', style: TextStyle(fontSize: 50)),
                  SizedBox(height: 10),
                  Text('لا توجد تصنيفات', style: TextStyle(color: kTextSec, fontSize: 15)),
                ]))
              : ListView.builder(
                  padding: const EdgeInsets.only(bottom: 80, left: 10, right: 10),
                  itemCount: _shown.length,
                  itemBuilder: (_, i) {
                    final c = _shown[i];
                    return Card(
                      margin: const EdgeInsets.only(bottom: 6),
                      child: ListTile(
                        leading: Text(_icons[i % _icons.length], style: const TextStyle(fontSize: 26)),
                        title: Text(c.name, textDirection: TextDirection.rtl,
                            style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
                        subtitle: c.description.isNotEmpty
                            ? Text(c.description, textDirection: TextDirection.rtl,
                                style: const TextStyle(fontSize: 11))
                            : null,
                        trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                          IconButton(icon: const Icon(Icons.edit, color: kPrimary, size: 20),
                              onPressed: () => _openForm(cat: c)),
                          IconButton(icon: const Icon(Icons.delete, color: kDanger, size: 20),
                              onPressed: () => _delete(c)),
                        ]),
                      ),
                    );
                  },
                ),
        )),
      ]),
      floatingActionButton: FloatingActionButton(
        backgroundColor: kPrimary,
        child: const Icon(Icons.add, color: Colors.white),
        onPressed: () => _openForm(),
      ),
    );
  }
}

// ═══════════════════════════════════════════
//  MEDICINE TYPES SCREEN (أنواع الأدوية)
// ═══════════════════════════════════════════
class MedicineTypesScreen extends StatefulWidget {
  const MedicineTypesScreen({super.key});
  @override State<MedicineTypesScreen> createState() => _MedicineTypesScreenState();
}

class _MedicineTypesScreenState extends State<MedicineTypesScreen> {
  List<MedicineType> _all = [], _shown = [];
  final _search = TextEditingController();

  @override void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    final d = await DB.getMedicineTypes();
    if (mounted) setState(() { _all = d; _apply(); });
  }

  void _apply() {
    final q = _search.text;
    setState(() => _shown = q.isEmpty
        ? List.from(_all)
        : _all.where((t) => t.name.contains(q)).toList());
  }

  void _openForm({MedicineType? type}) {
    final ctrl = TextEditingController(text: type?.name ?? '');
    final suggestions = ['مضاد حيوي','مسكن ألم','مكمل غذائي','خافض حرارة','مضاد حساسية','مهدئ','ملين','قطرات'];
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (_) => Padding(
        padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom, left: 16, right: 16, top: 16),
        child: StatefulBuilder(builder: (ctx, setS) => Column(mainAxisSize: MainAxisSize.min, children: [
          Container(width: 40, height: 4, decoration: BoxDecoration(color: Colors.grey[300], borderRadius: BorderRadius.circular(2))),
          const SizedBox(height: 12),
          Text(type == null ? 'إضافة نوع جديد' : 'تعديل النوع',
              style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: kPrimary)),
          const SizedBox(height: 14),
          TextField(controller: ctrl, textDirection: TextDirection.rtl, autofocus: true,
            decoration: const InputDecoration(labelText: 'اسم النوع *', prefixIcon: Icon(Icons.science))),
          const SizedBox(height: 10),
          // اقتراحات
          Align(alignment: Alignment.centerRight,
            child: const Text('اقتراحات سريعة:', style: TextStyle(fontSize: 12, color: kTextSec))),
          const SizedBox(height: 6),
          Wrap(spacing: 6, runSpacing: 4, children: suggestions.map((s) =>
            ActionChip(
              label: Text(s, style: const TextStyle(fontSize: 11)),
              backgroundColor: kLightGreen,
              side: const BorderSide(color: kAccent),
              onPressed: () { ctrl.text = s; setS(() {}); },
            )
          ).toList()),
          const SizedBox(height: 14),
          SizedBox(width: double.infinity, child: ElevatedButton.icon(
            icon: const Icon(Icons.save),
            label: Text(type == null ? 'إضافة' : 'حفظ التعديلات'),
            onPressed: () async {
              if (ctrl.text.trim().isEmpty) return;
              final t = MedicineType(id: type?.id, name: ctrl.text.trim());
              if (type == null) await DB.addMedicineType(t);
              else await DB.updateMedicineType(t);
              if (context.mounted) Navigator.pop(context);
              _load();
            },
          )),
          const SizedBox(height: 16),
        ])),
      ),
    );
  }

  Future<void> _delete(MedicineType t) async {
    final ok = await showDialog<bool>(context: context, builder: (_) => AlertDialog(
      title: const Text('حذف النوع'),
      content: Text('حذف "${t.name}"؟'),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('إلغاء')),
        TextButton(onPressed: () => Navigator.pop(context, true),
            child: const Text('حذف', style: TextStyle(color: kDanger))),
      ],
    ));
    if (ok == true) { await DB.deleteMedicineType(t.id!); _load(); }
  }

  final _colors = [
    Color(0xFFE53935), Color(0xFFFB8C00), Color(0xFF8E24AA), Color(0xFF43A047),
    Color(0xFF00ACC1), Color(0xFF3949AB), Color(0xFFF4511E), Color(0xFF039BE5),
    Color(0xFF6D4C41), Color(0xFF00897B), Color(0xFFD81B60), Color(0xFF546E7A),
  ];
  final _icons2 = ['🦠','🔥','💊','🌿','🍄','🩺','🩸','😴','🌊','💉','🧴','🔬'];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBg,
      appBar: AppBar(title: const Text('أنواع الأدوية')),
      body: Column(children: [
        // رأس
        Padding(padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
          child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            CircleAvatar(radius: 18, backgroundColor: kSecondary,
              child: IconButton(padding: EdgeInsets.zero,
                  icon: const Icon(Icons.add, color: Colors.white, size: 20),
                  onPressed: () => _openForm())),
            Text('أنواع الأدوية (${_all.length})',
                style: const TextStyle(fontWeight: FontWeight.bold, color: kPrimary, fontSize: 15)),
          ]),
        ),
        // معلومة
        Container(
          margin: const EdgeInsets.symmetric(horizontal: 12),
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(color: const Color(0xFFE3F2FD), borderRadius: BorderRadius.circular(10)),
          child: const Row(children: [
            Expanded(child: Text('أنواع الأدوية تصف طبيعة الدواء مثل: مضاد حيوي، مسكن ألم...',
                style: TextStyle(fontSize: 11, color: Color(0xFF1565C0)), textDirection: TextDirection.rtl)),
            SizedBox(width: 6),
            Icon(Icons.info_outline, color: Color(0xFF1565C0), size: 18),
          ]),
        ),
        const SizedBox(height: 8),
        // بحث
        Padding(padding: const EdgeInsets.symmetric(horizontal: 12),
          child: TextField(controller: _search, onChanged: (_) => _apply(), textDirection: TextDirection.rtl,
            decoration: InputDecoration(
              hintText: 'بحث في أنواع الأدوية...',
              prefixIcon: const Icon(Icons.search),
              filled: true, fillColor: Colors.white,
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide.none),
              contentPadding: const EdgeInsets.symmetric(vertical: 10),
            ),
          ),
        ),
        const SizedBox(height: 8),
        // شبكة
        Expanded(child: RefreshIndicator(onRefresh: _load,
          child: _shown.isEmpty
              ? Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                  const Text('💊', style: TextStyle(fontSize: 50)),
                  const SizedBox(height: 10),
                  const Text('لا توجد أنواع', style: TextStyle(color: kTextSec, fontSize: 15)),
                  const SizedBox(height: 14),
                  ElevatedButton.icon(
                    icon: const Icon(Icons.add),
                    label: const Text('أضف أول نوع'),
                    onPressed: () => _openForm(),
                  ),
                ]))
              : GridView.builder(
                  padding: const EdgeInsets.only(bottom: 80, left: 10, right: 10),
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2, childAspectRatio: 1.3, crossAxisSpacing: 8, mainAxisSpacing: 8),
                  itemCount: _shown.length,
                  itemBuilder: (_, i) {
                    final t = _shown[i];
                    final color = _colors[i % _colors.length];
                    return Card(
                      child: InkWell(
                        borderRadius: BorderRadius.circular(12),
                        onLongPress: () => _openForm(type: t),
                        child: Padding(padding: const EdgeInsets.all(10),
                          child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                            CircleAvatar(radius: 20, backgroundColor: color,
                              child: Text(_icons2[i % _icons2.length], style: const TextStyle(fontSize: 18))),
                            const SizedBox(height: 6),
                            Text(t.name, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12),
                                textAlign: TextAlign.center, maxLines: 2, overflow: TextOverflow.ellipsis),
                            const SizedBox(height: 4),
                            Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                              GestureDetector(
                                onTap: () => _openForm(type: t),
                                child: const Icon(Icons.edit, size: 16, color: kPrimary),
                              ),
                              const SizedBox(width: 10),
                              GestureDetector(
                                onTap: () => _delete(t),
                                child: const Icon(Icons.delete, size: 16, color: kDanger),
                              ),
                            ]),
                          ]),
                        ),
                      ),
                    );
                  },
                ),
        )),
      ]),
      floatingActionButton: FloatingActionButton(
        backgroundColor: kSecondary,
        child: const Icon(Icons.add, color: Colors.white),
        onPressed: () => _openForm(),
      ),
    );
  }
}
