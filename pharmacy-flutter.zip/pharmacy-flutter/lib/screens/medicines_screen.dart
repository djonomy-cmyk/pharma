import 'package:flutter/material.dart';
import '../main.dart';
import '../database.dart';
import '../models.dart';

// ═══════════════════════════════════════════
//  MEDICINES SCREEN
// ═══════════════════════════════════════════
class MedicinesScreen extends StatefulWidget {
  const MedicinesScreen({super.key});
  @override State<MedicinesScreen> createState() => _MedicinesScreenState();
}

class _MedicinesScreenState extends State<MedicinesScreen> {
  List<Medicine> _all = [], _shown = [];
  final _search = TextEditingController();
  String _filter = 'all';

  @override void initState() { super.initState(); _load(); }
  @override void didChangeDependencies() { super.didChangeDependencies(); _load(); }

  Future<void> _load() async {
    final d = await DB.getMedicines();
    if (mounted) setState(() { _all = d; _apply(); });
  }

  void _apply() {
    var r = _all;
    if (_filter == 'low') r = r.where((m) => m.isLowStock && !m.isOutOfStock).toList();
    if (_filter == 'out') r = r.where((m) => m.isOutOfStock).toList();
    final q = _search.text.toLowerCase();
    if (q.isNotEmpty) r = r.where((m) => m.name.contains(q) || (m.categoryName).contains(q)).toList();
    setState(() => _shown = r);
  }

  Future<void> _delete(Medicine m) async {
    final ok = await showDialog<bool>(context: context, builder: (_) => AlertDialog(
      title: const Text('حذف الدواء'),
      content: Text('حذف "${m.name}"؟'),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('إلغاء')),
        TextButton(onPressed: () => Navigator.pop(context, true),
            child: const Text('حذف', style: TextStyle(color: kDanger))),
      ],
    ));
    if (ok == true) { await DB.deleteMedicine(m.id!); _load(); }
  }

  Color _stockColor(Medicine m) {
    if (m.isOutOfStock) return kDanger;
    if (m.isLowStock) return kWarning;
    return kAccent;
  }

  @override
  Widget build(BuildContext context) {
    final lowCount = _all.where((m) => m.isLowStock && !m.isOutOfStock).length;
    final outCount = _all.where((m) => m.isOutOfStock).length;

    return Scaffold(
      backgroundColor: kBg,
      appBar: AppBar(title: const Text('الأدوية والمخزون')),
      body: Column(children: [
        // إحصاء
        Container(color: Colors.white, padding: const EdgeInsets.symmetric(vertical: 10),
          child: Row(children: [
            _Pill(_all.length.toString(), 'دواء', kPrimary),
            const VerticalDivider(),
            _Pill('$lowCount', 'مخزون منخفض', kWarning),
            const VerticalDivider(),
            _Pill('$outCount', 'نفد', kDanger),
          ]),
        ),
        // بحث
        Padding(padding: const EdgeInsets.all(10),
          child: TextField(
            controller: _search, onChanged: (_) => _apply(),
            textDirection: TextDirection.rtl,
            decoration: InputDecoration(
              hintText: 'بحث باسم الدواء أو التصنيف...',
              prefixIcon: const Icon(Icons.search),
              suffixIcon: _search.text.isNotEmpty
                  ? IconButton(icon: const Icon(Icons.close), onPressed: () { _search.clear(); _apply(); })
                  : null,
              filled: true, fillColor: Colors.white,
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide.none),
            ),
          ),
        ),
        // فلاتر
        Padding(padding: const EdgeInsets.symmetric(horizontal: 10),
          child: Row(children: [
            for (final f in [('all','الكل'), ('low','مخزون منخفض'), ('out','نفد')])
              Expanded(child: Padding(padding: const EdgeInsets.symmetric(horizontal: 2),
                child: TextButton(
                  onPressed: () { setState(() => _filter = f.$1); _apply(); },
                  style: TextButton.styleFrom(
                    backgroundColor: _filter == f.$1 ? kPrimary : Colors.white,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                    padding: const EdgeInsets.symmetric(vertical: 6),
                  ),
                  child: Text(f.$2, style: TextStyle(
                      color: _filter == f.$1 ? Colors.white : kTextSec,
                      fontSize: 11, fontWeight: FontWeight.bold)),
                ),
              )),
          ]),
        ),
        const SizedBox(height: 4),
        // قائمة
        Expanded(child: RefreshIndicator(onRefresh: _load,
          child: _shown.isEmpty
              ? const Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                  Icon(Icons.medication_outlined, size: 64, color: Colors.black26),
                  SizedBox(height: 12),
                  Text('لا توجد أدوية', style: TextStyle(color: kTextSec, fontSize: 15)),
                ]))
              : ListView.builder(
                  padding: const EdgeInsets.only(bottom: 80, left: 10, right: 10, top: 4),
                  itemCount: _shown.length,
                  itemBuilder: (_, i) {
                    final m = _shown[i];
                    return Card(
                      margin: const EdgeInsets.only(bottom: 6),
                      child: Padding(
                        padding: const EdgeInsets.all(10),
                        child: Row(children: [
                          // شارة المخزون
                          Column(children: [
                            CircleAvatar(
                              radius: 26,
                              backgroundColor: _stockColor(m),
                              child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                                Text('${m.stock}', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 14)),
                                Text(m.unit, style: const TextStyle(color: Colors.white70, fontSize: 8)),
                              ]),
                            ),
                          ]),
                          const SizedBox(width: 10),
                          // معلومات
                          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                            Text(m.name, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14), textDirection: TextDirection.rtl),
                            const SizedBox(height: 3),
                            Wrap(spacing: 4, children: [
                              if (m.categoryName.isNotEmpty) _Tag(m.categoryName, kLightGreen, kPrimary),
                              if (m.typeName.isNotEmpty) _Tag(m.typeName, const Color(0xFFE3F2FD), const Color(0xFF1565C0)),
                            ]),
                            const SizedBox(height: 4),
                            Row(mainAxisAlignment: MainAxisAlignment.end, children: [
                              Text('بيع: ${m.sellPrice.toStringAsFixed(2)} دج',
                                  style: const TextStyle(color: kPrimary, fontWeight: FontWeight.bold, fontSize: 11)),
                              const Text(' | ', style: TextStyle(color: kTextSec, fontSize: 11)),
                              Text('شراء: ${m.buyPrice.toStringAsFixed(2)} دج',
                                  style: const TextStyle(color: kTextSec, fontSize: 11)),
                            ]),
                            Text('حد التنبيه: ${m.minStock} ${m.unit}',
                                style: TextStyle(fontSize: 10,
                                    color: m.isLowStock ? kDanger : kTextSec)),
                          ])),
                          // أزرار
                          Column(children: [
                            IconButton(
                              icon: const Icon(Icons.edit, color: kPrimary, size: 20),
                              onPressed: () async {
                                await Navigator.push(context, MaterialPageRoute(
                                    builder: (_) => AddEditMedicineScreen(medicine: m)));
                                _load();
                              },
                            ),
                            IconButton(
                              icon: const Icon(Icons.delete, color: kDanger, size: 20),
                              onPressed: () => _delete(m),
                            ),
                          ]),
                        ]),
                      ),
                    );
                  },
                ),
        )),
      ]),
      floatingActionButton: FloatingActionButton(
        backgroundColor: kSecondary,
        child: const Icon(Icons.add, color: Colors.white),
        onPressed: () async {
          await Navigator.push(context, MaterialPageRoute(builder: (_) => const AddEditMedicineScreen()));
          _load();
        },
      ),
    );
  }
}

class _Pill extends StatelessWidget {
  final String value, label;
  final Color color;
  const _Pill(this.value, this.label, this.color);
  @override Widget build(_) => Expanded(child: Column(children: [
    Text(value, style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: color)),
    Text(label, style: const TextStyle(fontSize: 10, color: kTextSec)),
  ]));
}

class _Tag extends StatelessWidget {
  final String text;
  final Color bg, fg;
  const _Tag(this.text, this.bg, this.fg);
  @override Widget build(_) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
    decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(6)),
    child: Text(text, style: TextStyle(color: fg, fontSize: 10, fontWeight: FontWeight.bold)),
  );
}

// ═══════════════════════════════════════════
//  ADD / EDIT MEDICINE SCREEN
// ═══════════════════════════════════════════
class AddEditMedicineScreen extends StatefulWidget {
  final Medicine? medicine;
  const AddEditMedicineScreen({super.key, this.medicine});
  @override State<AddEditMedicineScreen> createState() => _AddEditMedicineState();
}

class _AddEditMedicineState extends State<AddEditMedicineScreen> {
  final _name    = TextEditingController();
  final _buyPrice  = TextEditingController();
  final _sellPrice = TextEditingController();
  final _stock   = TextEditingController();
  final _minStock = TextEditingController();
  final _desc    = TextEditingController();

  List<DiseaseCategory> _categories = [];
  List<MedicineType>    _types      = [];
  DiseaseCategory? _selCategory;
  MedicineType?    _selType;
  String _unit = 'علبة';
  bool _saving = false;

  final _units = ['علبة', 'شريط', 'كبسول', 'أنبوب', 'زجاجة', 'كيس', 'حقنة', 'لتر', 'مل', 'غ', 'قطعة'];

  @override
  void initState() {
    super.initState();
    final m = widget.medicine;
    if (m != null) {
      _name.text     = m.name;
      _buyPrice.text  = m.buyPrice.toString();
      _sellPrice.text = m.sellPrice.toString();
      _stock.text    = m.stock.toString();
      _minStock.text = m.minStock.toString();
      _desc.text     = m.description;
      _unit          = m.unit;
    } else {
      _stock.text    = '0';
      _minStock.text = '5';
    }
    _loadPickerData();
  }

  Future<void> _loadPickerData() async {
    final cats  = await DB.getCategories();
    final types = await DB.getMedicineTypes();
    if (mounted) setState(() {
      _categories = cats;
      _types      = types;
      if (widget.medicine?.categoryId != null)
        _selCategory = cats.firstWhere((c) => c.id == widget.medicine!.categoryId, orElse: () => cats.first);
      if (widget.medicine?.typeId != null)
        _selType = types.firstWhere((t) => t.id == widget.medicine!.typeId, orElse: () => types.first);
    });
  }

  double get _profit => (double.tryParse(_sellPrice.text) ?? 0) - (double.tryParse(_buyPrice.text) ?? 0);

  Future<void> _save() async {
    if (_name.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('أدخل اسم الدواء')));
      return;
    }
    setState(() => _saving = true);
    final m = Medicine(
      id:          widget.medicine?.id,
      name:        _name.text.trim(),
      categoryId:  _selCategory?.id,
      typeId:      _selType?.id,
      buyPrice:    double.tryParse(_buyPrice.text)  ?? 0,
      sellPrice:   double.tryParse(_sellPrice.text) ?? 0,
      stock:       int.tryParse(_stock.text)    ?? 0,
      minStock:    int.tryParse(_minStock.text)  ?? 5,
      unit:        _unit,
      description: _desc.text.trim(),
    );
    if (widget.medicine == null) await DB.addMedicine(m);
    else await DB.updateMedicine(m);
    if (mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text(widget.medicine == null ? 'إضافة دواء' : 'تعديل الدواء')),
    backgroundColor: kBg,
    body: ListView(padding: const EdgeInsets.all(14), children: [

      // ── المعلومات الأساسية
      _Section('📋 المعلومات الأساسية', [
        _FldCtrl('اسم الدواء *', Icons.medication, _name),
        _FldCtrl('الوصف', Icons.notes, _desc, lines: 2),
      ]),

      // ── التصنيف والنوع
      _Section('🗂️ التصنيف والنوع', [
        const Text('تصنيف المرض', style: TextStyle(fontSize: 12, color: kPrimary, fontWeight: FontWeight.bold)),
        const SizedBox(height: 6),
        _DropdownPicker<DiseaseCategory>(
          value: _selCategory,
          items: _categories,
          itemLabel: (c) => c.name,
          hint: 'اختر تصنيف المرض...',
          onChanged: (v) => setState(() => _selCategory = v),
        ),
        const SizedBox(height: 10),
        const Text('نوع الدواء', style: TextStyle(fontSize: 12, color: kPrimary, fontWeight: FontWeight.bold)),
        const SizedBox(height: 6),
        _DropdownPicker<MedicineType>(
          value: _selType,
          items: _types,
          itemLabel: (t) => t.name,
          hint: 'اختر نوع الدواء...',
          onChanged: (v) => setState(() => _selType = v),
        ),
      ]),

      // ── الأسعار
      _Section('💰 الأسعار', [
        Row(children: [
          Expanded(child: _FldCtrl('سعر الشراء (دج)', Icons.arrow_downward, _buyPrice,
              type: TextInputType.number, onChanged: (_) => setState(() {}))),
          const SizedBox(width: 10),
          Expanded(child: _FldCtrl('سعر البيع (دج)', Icons.arrow_upward, _sellPrice,
              type: TextInputType.number, onChanged: (_) => setState(() {}))),
        ]),
        if (_buyPrice.text.isNotEmpty && _sellPrice.text.isNotEmpty)
          Container(
            margin: const EdgeInsets.only(top: 8),
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: _profit >= 0 ? kLightGreen : kDangerLight,
              borderRadius: BorderRadius.circular(8),
            ),
            child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              Text('${_profit.toStringAsFixed(2)} دج',
                  style: TextStyle(fontWeight: FontWeight.bold, color: _profit >= 0 ? kAccent : kDanger, fontSize: 16)),
              const Text('هامش الربح:', style: TextStyle(fontWeight: FontWeight.bold)),
            ]),
          ),
      ]),

      // ── المخزون
      _Section('📦 المخزون', [
        Row(children: [
          Expanded(child: _FldCtrl('الكمية الحالية', Icons.inventory, _stock, type: TextInputType.number)),
          const SizedBox(width: 10),
          Expanded(child: _FldCtrl('حد التنبيه', Icons.warning_amber, _minStock, type: TextInputType.number)),
        ]),
        const SizedBox(height: 10),
        const Text('وحدة القياس', style: TextStyle(fontSize: 12, color: kPrimary, fontWeight: FontWeight.bold)),
        const SizedBox(height: 6),
        DropdownButtonFormField<String>(
          value: _unit,
          items: _units.map((u) => DropdownMenuItem(value: u, child: Text(u))).toList(),
          onChanged: (v) => setState(() => _unit = v!),
          decoration: const InputDecoration(prefixIcon: Icon(Icons.straighten, size: 18)),
        ),
      ]),

      const SizedBox(height: 14),
      ElevatedButton.icon(
        icon: _saving
            ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
            : const Icon(Icons.save),
        label: Text(_saving ? 'جاري الحفظ...' : widget.medicine == null ? 'إضافة الدواء' : 'حفظ التعديلات'),
        style: ElevatedButton.styleFrom(backgroundColor: kSecondary),
        onPressed: _saving ? null : _save,
      ),
      const SizedBox(height: 20),
    ]),
  );
}

// ── مكونات مساعدة
class _Section extends StatelessWidget {
  final String title;
  final List<Widget> children;
  const _Section(this.title, this.children);
  @override Widget build(_) => Card(
    margin: const EdgeInsets.only(bottom: 10),
    child: Padding(padding: const EdgeInsets.all(14), child: Column(
      crossAxisAlignment: CrossAxisAlignment.end,
      children: [
        Text(title, style: const TextStyle(fontWeight: FontWeight.bold, color: kPrimary, fontSize: 14)),
        const SizedBox(height: 10),
        ...children,
      ],
    )),
  );
}

class _FldCtrl extends StatelessWidget {
  final String label;
  final IconData icon;
  final TextEditingController ctrl;
  final TextInputType type;
  final int lines;
  final ValueChanged<String>? onChanged;
  const _FldCtrl(this.label, this.icon, this.ctrl,
      {this.type = TextInputType.text, this.lines = 1, this.onChanged});
  @override Widget build(_) => Padding(
    padding: const EdgeInsets.only(bottom: 8),
    child: TextField(
      controller: ctrl, keyboardType: type, maxLines: lines,
      textDirection: TextDirection.rtl, textAlign: TextAlign.right,
      onChanged: onChanged,
      decoration: InputDecoration(labelText: label, prefixIcon: Icon(icon, size: 18)),
    ),
  );
}

class _DropdownPicker<T> extends StatelessWidget {
  final T? value;
  final List<T> items;
  final String Function(T) itemLabel;
  final String hint;
  final ValueChanged<T?> onChanged;
  const _DropdownPicker({required this.value, required this.items, required this.itemLabel, required this.hint, required this.onChanged});
  @override Widget build(_) => DropdownButtonFormField<T>(
    value: value,
    hint: Text(hint, style: const TextStyle(color: kTextSec, fontSize: 13)),
    items: items.map((i) => DropdownMenuItem<T>(value: i, child: Text(itemLabel(i), textDirection: TextDirection.rtl))).toList(),
    onChanged: onChanged,
    isExpanded: true,
    decoration: const InputDecoration(prefixIcon: Icon(Icons.arrow_drop_down, size: 20)),
  );
}
