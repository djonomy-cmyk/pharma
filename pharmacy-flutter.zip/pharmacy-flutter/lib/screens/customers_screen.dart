// ═══════════════════════════════════════════════════════════════
//  customers_screen.dart
// ═══════════════════════════════════════════════════════════════
import 'package:flutter/material.dart';
import '../main.dart';
import '../database.dart';
import '../models.dart';
import 'customer_detail_screen.dart';

class CustomersScreen extends StatefulWidget {
  const CustomersScreen({super.key});
  @override State<CustomersScreen> createState() => _CustomersScreenState();
}

class _CustomersScreenState extends State<CustomersScreen> {
  List<Customer> _all = [], _shown = [];
  final _search = TextEditingController();
  String _filter = 'all';

  @override void initState() { super.initState(); _load(); }
  @override void didChangeDependencies() { super.didChangeDependencies(); _load(); }

  Future<void> _load() async {
    final d = await DB.getCustomers();
    if (mounted) setState(() { _all = d; _apply(); });
  }

  void _apply() {
    var r = _all;
    if (_filter == 'debt') r = r.where((c) => c.remainingDebt > 0).toList();
    if (_filter == 'paid') r = r.where((c) => c.remainingDebt <= 0).toList();
    final q = _search.text.toLowerCase();
    if (q.isNotEmpty) r = r.where((c) => c.name.contains(q) || c.phone.contains(q)).toList();
    setState(() => _shown = r);
  }

  Future<void> _delete(Customer c) async {
    final ok = await showDialog<bool>(context: context, builder: (_) => AlertDialog(
      title: const Text('حذف العميل'),
      content: Text('حذف "${c.name}" وجميع بياناته؟'),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('إلغاء')),
        TextButton(onPressed: () => Navigator.pop(context, true),
            child: const Text('حذف', style: TextStyle(color: kDanger))),
      ],
    ));
    if (ok == true) { await DB.deleteCustomer(c.id!); _load(); }
  }

  @override
  Widget build(BuildContext context) {
    final totalDebt = _all.fold(0.0, (s, c) => s + c.remainingDebt);
    final debtors = _all.where((c) => c.remainingDebt > 0).length;

    return Scaffold(
      backgroundColor: kBg,
      appBar: AppBar(title: const Text('العملاء والديون')),
      body: Column(children: [
        // إحصاء
        Container(color: Colors.white, padding: const EdgeInsets.symmetric(vertical: 10),
          child: Row(children: [
            _Pill(_all.length.toString(), 'عميل', kPrimary),
            const VerticalDivider(), _Pill('$debtors', 'مديون', kDanger),
            const VerticalDivider(), _Pill('${totalDebt.toStringAsFixed(0)} دج', 'إجمالي', kDanger),
          ]),
        ),
        // بحث
        Padding(padding: const EdgeInsets.all(10),
          child: TextField(controller: _search, onChanged: (_) => _apply(), textDirection: TextDirection.rtl,
            decoration: InputDecoration(
              hintText: 'بحث بالاسم أو الهاتف...',
              prefixIcon: const Icon(Icons.search),
              suffixIcon: _search.text.isNotEmpty
                  ? IconButton(icon: const Icon(Icons.close), onPressed: () { _search.clear(); _apply(); })
                  : null,
              filled: true, fillColor: Colors.white,
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide.none),
            ),
          ),
        ),
        // فلاتر
        Padding(padding: const EdgeInsets.symmetric(horizontal: 10),
          child: Row(children: [
            for (final f in [('all','الكل'), ('debt','مديونون'), ('paid','بدون ديون')])
              Expanded(child: Padding(padding: const EdgeInsets.symmetric(horizontal: 2),
                child: TextButton(
                  onPressed: () { setState(() => _filter = f.$1); _apply(); },
                  style: TextButton.styleFrom(
                    backgroundColor: _filter == f.$1 ? kPrimary : Colors.white,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                  ),
                  child: Text(f.$2, style: TextStyle(
                      color: _filter == f.$1 ? Colors.white : kTextSec, fontSize: 12, fontWeight: FontWeight.bold)),
                ),
              )),
          ]),
        ),
        const SizedBox(height: 6),
        // قائمة
        Expanded(child: RefreshIndicator(onRefresh: _load,
          child: _shown.isEmpty
              ? const Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                  Icon(Icons.people_outline, size: 64, color: Colors.black26),
                  SizedBox(height: 12),
                  Text('لا يوجد عملاء', style: TextStyle(color: kTextSec, fontSize: 15)),
                ]))
              : ListView.builder(
                  padding: const EdgeInsets.only(bottom: 80),
                  itemCount: _shown.length,
                  itemBuilder: (_, i) {
                    final c = _shown[i];
                    return Card(margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                      child: ListTile(
                        leading: CircleAvatar(
                          backgroundColor: c.remainingDebt > 0 ? kDanger : kAccent,
                          child: Text(c.name[0], style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                        ),
                        title: Text(c.name, textDirection: TextDirection.rtl, style: const TextStyle(fontWeight: FontWeight.bold)),
                        subtitle: Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                          Text(c.phone.isEmpty ? 'بدون هاتف' : c.phone),
                          Text('إجمالي: ${c.totalDebt.toStringAsFixed(2)} | مدفوع: ${c.totalPaid.toStringAsFixed(2)}',
                              style: const TextStyle(fontSize: 10)),
                        ]),
                        trailing: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                          Text(c.remainingDebt.toStringAsFixed(2),
                              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14,
                                  color: c.remainingDebt > 0 ? kDanger : kAccent)),
                          const Text('دج متبقي', style: TextStyle(fontSize: 9, color: kTextSec)),
                          Row(mainAxisSize: MainAxisSize.min, children: [
                            IconButton(padding: EdgeInsets.zero, constraints: const BoxConstraints(),
                              icon: const Icon(Icons.edit, size: 16, color: kPrimary),
                              onPressed: () async {
                                await Navigator.push(context, MaterialPageRoute(
                                    builder: (_) => AddEditCustomerScreen(customer: c)));
                                _load();
                              }),
                            IconButton(padding: EdgeInsets.zero, constraints: const BoxConstraints(),
                              icon: const Icon(Icons.delete, size: 16, color: kDanger),
                              onPressed: () => _delete(c)),
                          ]),
                        ]),
                        onTap: () async {
                          await Navigator.push(context, MaterialPageRoute(
                              builder: (_) => CustomerDetailScreen(customerId: c.id!)));
                          _load();
                        },
                      ),
                    );
                  },
                ),
        )),
      ]),
      floatingActionButton: FloatingActionButton(
        backgroundColor: kPrimary,
        child: const Icon(Icons.person_add, color: Colors.white),
        onPressed: () async {
          await Navigator.push(context, MaterialPageRoute(builder: (_) => const AddEditCustomerScreen()));
          _load();
        },
      ),
    );
  }
}

class _Pill extends StatelessWidget {
  final String value, label;
  final Color color;
  const _Pill(this.value, this.label, this.color);
  @override Widget build(BuildContext context) => Expanded(child: Column(children: [
    Text(value, style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold, color: color)),
    Text(label, style: const TextStyle(fontSize: 10, color: kTextSec)),
  ]));
}
