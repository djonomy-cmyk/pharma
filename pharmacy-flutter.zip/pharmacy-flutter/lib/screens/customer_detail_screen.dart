import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';
import '../main.dart';
import '../database.dart';
import '../models.dart';

// ═══════════════════════════════════════════
//  CUSTOMER DETAIL
// ═══════════════════════════════════════════
class CustomerDetailScreen extends StatefulWidget {
  final int customerId;
  const CustomerDetailScreen({super.key, required this.customerId});
  @override State<CustomerDetailScreen> createState() => _CustomerDetailState();
}

class _CustomerDetailState extends State<CustomerDetailScreen> with SingleTickerProviderStateMixin {
  Customer? _customer;
  List<DebtTransaction> _debts = [];
  List<Payment> _payments = [];
  late TabController _tabs;

  @override void initState() { super.initState(); _tabs = TabController(length: 2, vsync: this); _load(); }
  @override void dispose() { _tabs.dispose(); super.dispose(); }

  Future<void> _load() async {
    final c = await DB.getCustomer(widget.customerId);
    final d = await DB.getDebts(widget.customerId);
    final p = await DB.getPayments(widget.customerId);
    if (mounted) setState(() { _customer = c; _debts = d; _payments = p; });
  }

  @override
  Widget build(BuildContext context) {
    if (_customer == null) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    final c = _customer!;
    final pct = c.totalDebt > 0 ? (c.totalPaid / c.totalDebt).clamp(0.0, 1.0) : 0.0;

    return Scaffold(
      backgroundColor: kBg,
      appBar: AppBar(
        title: Text(c.name),
        actions: [
          IconButton(icon: const Icon(Icons.edit), onPressed: () async {
            await Navigator.push(context, MaterialPageRoute(builder: (_) => AddEditCustomerScreen(customer: c)));
            _load();
          }),
        ],
      ),
      body: Column(children: [
        // بيانات + أرقام
        Container(color: kPrimary, padding: const EdgeInsets.all(14),
          child: Column(children: [
            Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              CircleAvatar(radius: 28, backgroundColor: Colors.white24,
                child: Text(c.name[0], style: const TextStyle(fontSize: 22, color: Colors.white, fontWeight: FontWeight.bold))),
              const SizedBox(width: 12),
              Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                Text(c.name, style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold)),
                if (c.phone.isNotEmpty) Text('📞 ${c.phone}', style: const TextStyle(color: Colors.white70, fontSize: 12)),
                if (c.address.isNotEmpty) Text('📍 ${c.address}', style: const TextStyle(color: Colors.white70, fontSize: 12)),
              ]),
            ]),
            const SizedBox(height: 12),
            Row(children: [
              _Num(c.totalDebt.toStringAsFixed(2), 'إجمالي الديون', Colors.white),
              const VerticalDivider(color: Colors.white30),
              _Num(c.totalPaid.toStringAsFixed(2), 'المدفوع', Colors.greenAccent),
              const VerticalDivider(color: Colors.white30),
              _Num(c.remainingDebt.toStringAsFixed(2), 'المتبقي', Colors.redAccent),
            ]),
            const SizedBox(height: 8),
            ClipRRect(borderRadius: BorderRadius.circular(6),
              child: LinearProgressIndicator(
                value: pct, minHeight: 8,
                backgroundColor: Colors.white24,
                valueColor: const AlwaysStoppedAnimation(Colors.greenAccent),
              )),
            const SizedBox(height: 4),
            Text('${(pct * 100).round()}% تم تسديده', style: const TextStyle(color: Colors.white70, fontSize: 11)),
          ]),
        ),
        // أزرار
        Container(color: Colors.white, padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
          child: Row(children: [
            Expanded(child: _ActBtn(Icons.add_circle, 'إضافة دين', kDanger, () async {
              await Navigator.push(context, MaterialPageRoute(
                  builder: (_) => AddDebtScreen(customerId: c.id!, customerName: c.name)));
              _load();
            })),
            const SizedBox(width: 6),
            Expanded(child: _ActBtn(Icons.payments, 'تسجيل دفعة', kAccent, () async {
              await Navigator.push(context, MaterialPageRoute(
                  builder: (_) => PaymentScreen(customerId: c.id!, customerName: c.name, remainingDebt: c.remainingDebt)));
              _load();
            })),
            const SizedBox(width: 6),
            Expanded(child: _ActBtn(Icons.receipt_long, 'فاتورة', kPrimary, () {
              Navigator.push(context, MaterialPageRoute(
                  builder: (_) => InvoiceScreen(customer: c, debts: _debts, payments: _payments)));
            })),
          ]),
        ),
        // تبويبات
        Container(color: Colors.white,
          child: TabBar(controller: _tabs, labelColor: kPrimary, unselectedLabelColor: kTextSec,
            indicatorColor: kPrimary,
            tabs: [Tab(text: 'الديون (${_debts.length})'), Tab(text: 'الدفعات (${_payments.length})')]),
        ),
        Expanded(child: TabBarView(controller: _tabs, children: [
          _debtsList(),
          _paymentsList(),
        ])),
      ]),
    );
  }

  Widget _debtsList() => _debts.isEmpty
      ? const Center(child: Text('لا توجد ديون ✅', style: TextStyle(color: kTextSec)))
      : ListView.builder(
          padding: const EdgeInsets.all(10),
          itemCount: _debts.length,
          itemBuilder: (_, i) {
            final d = _debts[i];
            return Card(child: ListTile(
              leading: const CircleAvatar(backgroundColor: kDangerLight, child: Icon(Icons.shopping_cart, color: kDanger, size: 18)),
              title: Text(d.medicineName.isEmpty ? 'دواء' : d.medicineName, textDirection: TextDirection.rtl, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
              subtitle: Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                Text(d.date, style: const TextStyle(fontSize: 10)),
                Text('${d.quantity} × ${d.unitPrice.toStringAsFixed(2)} دج', style: const TextStyle(fontSize: 11, color: kPrimary)),
                if (d.notes.isNotEmpty) Text(d.notes, style: const TextStyle(fontSize: 10, fontStyle: FontStyle.italic)),
              ]),
              trailing: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                Text(d.totalAmount.toStringAsFixed(2), style: const TextStyle(color: kDanger, fontWeight: FontWeight.bold, fontSize: 14)),
                const Text('دج', style: TextStyle(fontSize: 10, color: kTextSec)),
                IconButton(padding: EdgeInsets.zero, constraints: const BoxConstraints(),
                  icon: const Icon(Icons.delete_outline, size: 16, color: kDanger),
                  onPressed: () async {
                    await DB.deleteDebt(d.id!); _load();
                  }),
              ]),
            ));
          });

  Widget _paymentsList() => _payments.isEmpty
      ? const Center(child: Text('لا توجد دفعات', style: TextStyle(color: kTextSec)))
      : ListView.builder(
          padding: const EdgeInsets.all(10),
          itemCount: _payments.length,
          itemBuilder: (_, i) {
            final p = _payments[i];
            return Card(child: ListTile(
              leading: const CircleAvatar(backgroundColor: Color(0xFFE8F5E9), child: Icon(Icons.payments, color: kAccent, size: 18)),
              title: const Text('دفعة سداد', textDirection: TextDirection.rtl, style: TextStyle(fontWeight: FontWeight.bold)),
              subtitle: Text(p.date),
              trailing: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                Text(p.amount.toStringAsFixed(2), style: const TextStyle(color: kAccent, fontWeight: FontWeight.bold, fontSize: 14)),
                const Text('دج', style: TextStyle(fontSize: 10, color: kTextSec)),
              ]),
            ));
          });
}

class _Num extends StatelessWidget {
  final String v, l;
  final Color c;
  const _Num(this.v, this.l, this.c);
  @override Widget build(_) => Expanded(child: Column(children: [
    Text(v, style: TextStyle(color: c, fontWeight: FontWeight.bold, fontSize: 13)),
    Text(l, style: const TextStyle(color: Colors.white54, fontSize: 9), textAlign: TextAlign.center),
  ]));
}

class _ActBtn extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color color;
  final VoidCallback onTap;
  const _ActBtn(this.icon, this.label, this.color, this.onTap);
  @override Widget build(_) => ElevatedButton.icon(
    icon: Icon(icon, size: 15), label: Text(label, style: const TextStyle(fontSize: 11)),
    onPressed: onTap,
    style: ElevatedButton.styleFrom(backgroundColor: color, padding: const EdgeInsets.symmetric(vertical: 10)),
  );
}

// ═══════════════════════════════════════════
//  ADD / EDIT CUSTOMER
// ═══════════════════════════════════════════
class AddEditCustomerScreen extends StatefulWidget {
  final Customer? customer;
  const AddEditCustomerScreen({super.key, this.customer});
  @override State<AddEditCustomerScreen> createState() => _AddEditCustomerState();
}

class _AddEditCustomerState extends State<AddEditCustomerScreen> {
  final _form = GlobalKey<FormState>();
  late final TextEditingController _name, _phone, _address, _notes;
  bool _saving = false;

  @override void initState() {
    super.initState();
    final c = widget.customer;
    _name    = TextEditingController(text: c?.name    ?? '');
    _phone   = TextEditingController(text: c?.phone   ?? '');
    _address = TextEditingController(text: c?.address ?? '');
    _notes   = TextEditingController(text: c?.notes   ?? '');
  }

  @override void dispose() {
    _name.dispose(); _phone.dispose(); _address.dispose(); _notes.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    if (!_form.currentState!.validate()) return;
    setState(() => _saving = true);
    final c = Customer(
      id: widget.customer?.id,
      name: _name.text.trim(), phone: _phone.text.trim(),
      address: _address.text.trim(), notes: _notes.text.trim(),
    );
    if (widget.customer == null) await DB.addCustomer(c);
    else await DB.updateCustomer(c);
    if (mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text(widget.customer == null ? 'إضافة عميل' : 'تعديل العميل')),
    backgroundColor: kBg,
    body: Form(key: _form, child: ListView(padding: const EdgeInsets.all(16), children: [
      const SizedBox(height: 8),
      _Field('اسم العميل *', Icons.person, _name, required: true),
      _Field('رقم الهاتف', Icons.phone, _phone, type: TextInputType.phone),
      _Field('العنوان', Icons.location_on, _address),
      _Field('ملاحظات', Icons.notes, _notes, lines: 3),
      const SizedBox(height: 16),
      ElevatedButton.icon(
        icon: _saving ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white)) : const Icon(Icons.save),
        label: Text(_saving ? 'جاري الحفظ...' : widget.customer == null ? 'إضافة العميل' : 'حفظ التعديلات'),
        onPressed: _saving ? null : _save,
      ),
    ])),
  );
}

class _Field extends StatelessWidget {
  final String label;
  final IconData icon;
  final TextEditingController ctrl;
  final TextInputType type;
  final int lines;
  final bool required;
  const _Field(this.label, this.icon, this.ctrl, {this.type = TextInputType.text, this.lines = 1, this.required = false});
  @override Widget build(_) => Padding(
    padding: const EdgeInsets.only(bottom: 12),
    child: TextFormField(
      controller: ctrl, keyboardType: type, maxLines: lines,
      textDirection: TextDirection.rtl, textAlign: TextAlign.right,
      validator: required ? (v) => v!.trim().isEmpty ? 'هذا الحقل مطلوب' : null : null,
      decoration: InputDecoration(labelText: label, prefixIcon: Icon(icon, size: 18)),
    ),
  );
}

// ═══════════════════════════════════════════
//  ADD DEBT
// ═══════════════════════════════════════════
class AddDebtScreen extends StatefulWidget {
  final int customerId;
  final String customerName;
  const AddDebtScreen({super.key, required this.customerId, required this.customerName});
  @override State<AddDebtScreen> createState() => _AddDebtState();
}

class _AddDebtState extends State<AddDebtScreen> {
  final _medName = TextEditingController();
  final _qty     = TextEditingController(text: '1');
  final _price   = TextEditingController();
  final _notes   = TextEditingController();
  List<Medicine> _medicines = [];
  Medicine? _selMed;
  bool _updateStock = true, _saving = false, _showMeds = false;

  @override void initState() { super.initState(); DB.getMedicines().then((m) => setState(() => _medicines = m)); }

  double get _total => (double.tryParse(_qty.text) ?? 0) * (double.tryParse(_price.text) ?? 0);

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text('إضافة دين – ${widget.customerName}')),
    backgroundColor: kBg,
    body: ListView(padding: const EdgeInsets.all(14), children: [
      // اختيار الدواء
      Card(child: Padding(padding: const EdgeInsets.all(12), child: Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
        const Text('💊 الدواء', style: TextStyle(fontWeight: FontWeight.bold, color: kPrimary)),
        const SizedBox(height: 8),
        if (_selMed != null) ...[
          Container(padding: const EdgeInsets.all(10), decoration: BoxDecoration(color: const Color(0xFFE8F5E9), borderRadius: BorderRadius.circular(8)),
            child: Row(children: [
              IconButton(padding: EdgeInsets.zero, constraints: const BoxConstraints(),
                icon: const Icon(Icons.close, color: kDanger), onPressed: () => setState(() { _selMed = null; _medName.clear(); _price.clear(); })),
              const Spacer(),
              Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                Text(_selMed!.name, style: const TextStyle(fontWeight: FontWeight.bold, color: kPrimary)),
                Text('مخزون: ${_selMed!.stock} ${_selMed!.unit}', style: const TextStyle(fontSize: 11, color: kTextSec)),
              ]),
            ]),
          ),
          const SizedBox(height: 8),
          CheckboxListTile(value: _updateStock, onChanged: (v) => setState(() => _updateStock = v!),
            title: Text('خفض المخزون (${_selMed!.stock} متاح)', style: const TextStyle(fontSize: 13)),
            controlAffinity: ListTileControlAffinity.leading,
          ),
        ] else ...[
          OutlinedButton.icon(
            icon: const Icon(Icons.search), label: const Text('اختر من قائمة الأدوية'),
            onPressed: () => setState(() => _showMeds = !_showMeds),
            style: OutlinedButton.styleFrom(foregroundColor: kPrimary, side: const BorderSide(color: kPrimary)),
          ),
          if (_showMeds) SizedBox(height: 200, child: ListView.builder(
            itemCount: _medicines.length,
            itemBuilder: (_, i) {
              final m = _medicines[i];
              return ListTile(dense: true,
                title: Text(m.name, textDirection: TextDirection.rtl, style: const TextStyle(fontSize: 13)),
                trailing: Text('${m.sellPrice} دج | ${m.stock} ${m.unit}', style: const TextStyle(fontSize: 11)),
                onTap: () => setState(() {
                  _selMed = m; _medName.text = m.name;
                  _price.text = m.sellPrice.toString(); _showMeds = false;
                }),
              );
            },
          )),
        ],
        const SizedBox(height: 8),
        TextFormField(controller: _medName, textDirection: TextDirection.rtl,
          decoration: const InputDecoration(labelText: 'اسم الدواء / الخدمة *', prefixIcon: Icon(Icons.medical_services, size: 18))),
      ]))),
      const SizedBox(height: 8),
      // السعر والكمية
      Card(child: Padding(padding: const EdgeInsets.all(12), child: Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
        const Text('💰 السعر والكمية', style: TextStyle(fontWeight: FontWeight.bold, color: kPrimary)),
        const SizedBox(height: 8),
        Row(children: [
          Expanded(child: TextFormField(controller: _qty, keyboardType: TextInputType.number, textAlign: TextAlign.center,
            onChanged: (_) => setState(() {}),
            decoration: const InputDecoration(labelText: 'الكمية'))),
          const SizedBox(width: 10),
          Expanded(child: TextFormField(controller: _price, keyboardType: TextInputType.number, textAlign: TextAlign.center,
            onChanged: (_) => setState(() {}),
            decoration: const InputDecoration(labelText: 'السعر (دج)'))),
        ]),
        const SizedBox(height: 10),
        Container(padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: const Color(0xFFE8F5E9), borderRadius: BorderRadius.circular(8)),
          child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            Text('${_total.toStringAsFixed(2)} دج', style: const TextStyle(color: kDanger, fontWeight: FontWeight.bold, fontSize: 18)),
            const Text('الإجمالي:', style: TextStyle(fontWeight: FontWeight.bold)),
          ]),
        ),
      ]))),
      const SizedBox(height: 8),
      Card(child: Padding(padding: const EdgeInsets.all(12), child: TextFormField(controller: _notes,
        textDirection: TextDirection.rtl, maxLines: 2,
        decoration: const InputDecoration(labelText: 'ملاحظات', prefixIcon: Icon(Icons.notes))))),
      const SizedBox(height: 14),
      ElevatedButton.icon(
        icon: _saving ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white)) : const Icon(Icons.add_circle),
        label: Text(_saving ? 'جاري الحفظ...' : 'إضافة دين ${_total.toStringAsFixed(2)} دج'),
        style: ElevatedButton.styleFrom(backgroundColor: kDanger),
        onPressed: _saving ? null : () async {
          if (_medName.text.trim().isEmpty) { ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('أدخل اسم الدواء'))); return; }
          if (_total <= 0) { ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('أدخل سعراً وكمية صحيحة'))); return; }
          setState(() => _saving = true);
          await DB.addDebt(DebtTransaction(
            customerId: widget.customerId, medicineId: _selMed?.id,
            medicineName: _medName.text.trim(),
            quantity: double.tryParse(_qty.text) ?? 1,
            unitPrice: double.tryParse(_price.text) ?? 0,
            totalAmount: _total, notes: _notes.text.trim(),
          ), updateStock: _updateStock && _selMed != null);
          if (mounted) Navigator.pop(context);
        },
      ),
    ]),
  );
}

// ═══════════════════════════════════════════
//  PAYMENT
// ═══════════════════════════════════════════
class PaymentScreen extends StatefulWidget {
  final int customerId;
  final String customerName;
  final double remainingDebt;
  const PaymentScreen({super.key, required this.customerId, required this.customerName, required this.remainingDebt});
  @override State<PaymentScreen> createState() => _PaymentState();
}

class _PaymentState extends State<PaymentScreen> {
  final _amount = TextEditingController();
  final _notes  = TextEditingController();
  bool _saving  = false;

  Future<void> _save() async {
    final val = double.tryParse(_amount.text) ?? 0;
    if (val <= 0) { ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('أدخل مبلغاً صحيحاً'))); return; }
    setState(() => _saving = true);
    await DB.addPayment(Payment(customerId: widget.customerId, amount: val, notes: _notes.text.trim()));
    if (mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text('تسجيل دفعة – ${widget.customerName}')),
    backgroundColor: kBg,
    body: ListView(padding: const EdgeInsets.all(14), children: [
      // دين متبقي
      Card(color: kDangerLight, child: Padding(padding: const EdgeInsets.all(16), child: Column(children: [
        const Text('الدين المتبقي', style: TextStyle(color: kDanger, fontWeight: FontWeight.bold)),
        const SizedBox(height: 6),
        Text('${widget.remainingDebt.toStringAsFixed(2)} دج',
            style: const TextStyle(color: kDanger, fontSize: 28, fontWeight: FontWeight.bold)),
      ]))),
      const SizedBox(height: 8),
      // سداد كامل
      if (widget.remainingDebt > 0) ElevatedButton.icon(
        icon: const Icon(Icons.done_all),
        label: Text('سداد كامل (${widget.remainingDebt.toStringAsFixed(2)} دج)'),
        style: ElevatedButton.styleFrom(backgroundColor: kAccent),
        onPressed: () => _amount.text = widget.remainingDebt.toStringAsFixed(2),
      ),
      const SizedBox(height: 8),
      // مبالغ سريعة
      Card(child: Padding(padding: const EdgeInsets.all(12), child: Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
        const Text('⚡ مبالغ سريعة', style: TextStyle(fontWeight: FontWeight.bold, color: kPrimary)),
        const SizedBox(height: 8),
        Wrap(spacing: 8, children: [500, 1000, 2000, 5000].map((v) => ActionChip(
          label: Text('$v دج'), backgroundColor: const Color(0xFFE8F5E9),
          onPressed: () => _amount.text = v.toString(),
        )).toList()),
      ]))),
      const SizedBox(height: 8),
      Card(child: Padding(padding: const EdgeInsets.all(12), child: Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
        const Text('💰 مبلغ الدفعة', style: TextStyle(fontWeight: FontWeight.bold, color: kPrimary)),
        const SizedBox(height: 8),
        TextFormField(controller: _amount, keyboardType: TextInputType.number, textAlign: TextAlign.center,
          style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: kPrimary),
          decoration: const InputDecoration(suffixText: 'دج', hintText: '0.00')),
        const SizedBox(height: 8),
        TextFormField(controller: _notes, textDirection: TextDirection.rtl, maxLines: 2,
          decoration: const InputDecoration(labelText: 'ملاحظات', prefixIcon: Icon(Icons.notes))),
      ]))),
      const SizedBox(height: 14),
      ElevatedButton.icon(
        icon: _saving ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white)) : const Icon(Icons.save),
        label: Text(_saving ? 'جاري الحفظ...' : 'تسجيل الدفعة'),
        style: ElevatedButton.styleFrom(backgroundColor: kAccent),
        onPressed: _saving ? null : _save,
      ),
    ]),
  );
}

// ═══════════════════════════════════════════
//  INVOICE
// ═══════════════════════════════════════════
class InvoiceScreen extends StatelessWidget {
  final Customer customer;
  final List<DebtTransaction> debts;
  final List<Payment> payments;
  const InvoiceScreen({super.key, required this.customer, required this.debts, required this.payments});

  String _buildText() {
    final totalDebt = debts.fold(0.0, (s, d) => s + d.totalAmount);
    final totalPaid = payments.fold(0.0, (s, p) => s + p.amount);
    final remaining = totalDebt - totalPaid;
    var t = '═══════════════════════════\n🏥 فاتورة الصيدلية\n═══════════════════════════\n';
    t += 'العميل : ${customer.name}\n';
    if (customer.phone.isNotEmpty) t += 'الهاتف : ${customer.phone}\n';
    t += '───────────────────────────\n';
    t += 'تفاصيل الديون:\n';
    for (int i = 0; i < debts.length; i++) {
      final d = debts[i];
      t += '${i+1}. ${d.medicineName}\n   ${d.quantity} × ${d.unitPrice.toStringAsFixed(2)} = ${d.totalAmount.toStringAsFixed(2)} دج\n';
    }
    t += '───────────────────────────\n';
    t += 'إجمالي الديون : ${totalDebt.toStringAsFixed(2)} دج\n';
    if (payments.isNotEmpty) {
      t += '\nالدفعات:\n';
      for (final p in payments) t += '  ${p.amount.toStringAsFixed(2)} دج  (${p.date})\n';
      t += 'إجمالي المدفوع: ${totalPaid.toStringAsFixed(2)} دج\n';
    }
    t += '═══════════════════════════\n';
    t += 'المتبقي : ${remaining.toStringAsFixed(2)} دج\n';
    t += '═══════════════════════════\n';
    t += 'شكراً على ثقتكم 🙏\n';
    return t;
  }

  @override
  Widget build(BuildContext context) {
    final totalDebt = debts.fold(0.0, (s, d) => s + d.totalAmount);
    final totalPaid = payments.fold(0.0, (s, p) => s + p.amount);
    final remaining = totalDebt - totalPaid;

    return Scaffold(
      appBar: AppBar(
        title: const Text('فاتورة الدين'),
        actions: [IconButton(icon: const Icon(Icons.share), onPressed: () => Share.share(_buildText()))],
      ),
      backgroundColor: const Color(0xFFE8E8E8),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(12),
        child: Card(
          child: Column(children: [
            Container(width: double.infinity, color: kPrimary, padding: const EdgeInsets.all(16),
              child: Column(children: [
                const Text('🏥 فاتورة الصيدلية', style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
              ])),
            Padding(padding: const EdgeInsets.all(14), child: Column(children: [
              _Row('العميل', customer.name),
              if (customer.phone.isNotEmpty) _Row('الهاتف', customer.phone),
              if (customer.address.isNotEmpty) _Row('العنوان', customer.address),
              const Divider(),
              // ديون
              const Align(alignment: Alignment.centerRight,
                child: Text('📋 تفاصيل الديون', style: TextStyle(fontWeight: FontWeight.bold, color: kPrimary))),
              const SizedBox(height: 6),
              Container(color: const Color(0xFFE8F5E9), padding: const EdgeInsets.symmetric(vertical: 6, horizontal: 8),
                child: const Row(children: [
                  Expanded(flex: 3, child: Text('الدواء', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 11), textAlign: TextAlign.right)),
                  Expanded(child: Text('الكمية', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 11), textAlign: TextAlign.center)),
                  Expanded(child: Text('السعر', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 11), textAlign: TextAlign.center)),
                  Expanded(child: Text('الإجمالي', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 11), textAlign: TextAlign.center)),
                ])),
              ...debts.asMap().entries.map((e) => Container(
                color: e.key.isEven ? Colors.white : const Color(0xFFFAFAFA),
                padding: const EdgeInsets.symmetric(vertical: 5, horizontal: 8),
                child: Row(children: [
                  Expanded(flex: 3, child: Text(e.value.medicineName, style: const TextStyle(fontSize: 11), textAlign: TextAlign.right)),
                  Expanded(child: Text('${e.value.quantity}', style: const TextStyle(fontSize: 11), textAlign: TextAlign.center)),
                  Expanded(child: Text(e.value.unitPrice.toStringAsFixed(2), style: const TextStyle(fontSize: 11), textAlign: TextAlign.center)),
                  Expanded(child: Text(e.value.totalAmount.toStringAsFixed(2), style: const TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: kDanger), textAlign: TextAlign.center)),
                ]),
              )),
              const Divider(),
              _Row('إجمالي الديون', '${totalDebt.toStringAsFixed(2)} دج', color: kDanger),
              if (payments.isNotEmpty) ...[
                const SizedBox(height: 8),
                const Align(alignment: Alignment.centerRight,
                  child: Text('💰 الدفعات', style: TextStyle(fontWeight: FontWeight.bold, color: kPrimary))),
                ...payments.map((p) => _Row(p.date, '${p.amount.toStringAsFixed(2)} دج', color: kAccent)),
                _Row('إجمالي المدفوع', '${totalPaid.toStringAsFixed(2)} دج', color: kAccent),
              ],
              const Divider(thickness: 2),
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: remaining > 0 ? kDangerLight : const Color(0xFFE8F5E9),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                  Text('${remaining.toStringAsFixed(2)} دج',
                      style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold,
                          color: remaining > 0 ? kDanger : kAccent)),
                  const Text('المبلغ المتبقي', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                ]),
              ),
              if (remaining <= 0) const Padding(
                padding: EdgeInsets.only(top: 8),
                child: Text('✅ تم السداد بالكامل', style: TextStyle(color: kAccent, fontWeight: FontWeight.bold)),
              ),
              const SizedBox(height: 12),
              const Text('شكراً على ثقتكم 🙏', style: TextStyle(color: kTextSec)),
            ])),
          ]),
        ),
      ),
      bottomNavigationBar: Padding(
        padding: const EdgeInsets.all(12),
        child: ElevatedButton.icon(
          icon: const Icon(Icons.share),
          label: const Text('مشاركة / إرسال'),
          onPressed: () => Share.share(_buildText()),
        ),
      ),
    );
  }
}

class _Row extends StatelessWidget {
  final String l, v;
  final Color? color;
  const _Row(this.l, this.v, {this.color});
  @override Widget build(_) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 3),
    child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
      Text(v, style: TextStyle(fontWeight: FontWeight.bold, color: color ?? Colors.black87)),
      Text(l, style: const TextStyle(color: kTextSec)),
    ]),
  );
}
