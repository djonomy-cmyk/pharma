import 'package:flutter/material.dart';
import '../main.dart';
import '../database.dart';
import '../models.dart';
import 'customer_detail_screen.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});
  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  DashboardStats _stats = DashboardStats();
  List<Customer> _debtors = [];
  List<Medicine> _lowStock = [];
  List<Customer> _allCustomers = [];
  List<Customer> _searchResults = [];
  final _searchCtrl = TextEditingController();
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final stats    = await DB.getStats();
    final debtors  = await DB.getTopDebtors(limit: 5);
    final lowStock = await DB.getLowStockMedicines();
    final customers = await DB.getCustomers();
    if (mounted) setState(() {
      _stats = stats;
      _debtors = debtors;
      _lowStock = lowStock.take(4).toList();
      _allCustomers = customers;
      _loading = false;
    });
  }

  void _search(String q) {
    if (q.isEmpty) { setState(() => _searchResults = []); return; }
    setState(() => _searchResults = _allCustomers
        .where((c) => c.name.contains(q) || c.phone.contains(q)).toList());
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBg,
      appBar: AppBar(title: const Text('🏥 إدارة الصيدلية')),
      body: RefreshIndicator(
        onRefresh: _load,
        child: _loading
            ? const Center(child: CircularProgressIndicator())
            : ListView(
                children: [
                  _buildSearch(),
                  if (_searchResults.isNotEmpty) _buildSearchResults(),
                  _buildStatsGrid(),
                  _buildProgressCard(),
                  _buildDebtorsCard(),
                  if (_lowStock.isNotEmpty) _buildLowStockCard(),
                  _buildQuickActions(),
                  const SizedBox(height: 20),
                ],
              ),
      ),
    );
  }

  Widget _buildSearch() {
    return Padding(
      padding: const EdgeInsets.all(12),
      child: TextField(
        controller: _searchCtrl,
        onChanged: _search,
        textDirection: TextDirection.rtl,
        decoration: InputDecoration(
          hintText: 'ابحث عن عميل بالاسم أو الهاتف...',
          hintTextDirection: TextDirection.rtl,
          prefixIcon: const Icon(Icons.search),
          suffixIcon: _searchCtrl.text.isNotEmpty
              ? IconButton(icon: const Icon(Icons.close), onPressed: () {
                  _searchCtrl.clear(); setState(() => _searchResults = []);
                })
              : null,
          filled: true, fillColor: Colors.white,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
          contentPadding: const EdgeInsets.symmetric(vertical: 12, horizontal: 14),
        ),
      ),
    );
  }

  Widget _buildSearchResults() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [BoxShadow(color: Colors.black12, blurRadius: 4)],
      ),
      child: Column(
        children: _searchResults.map((c) => ListTile(
          leading: CircleAvatar(
            backgroundColor: c.remainingDebt > 0 ? kDanger : kAccent,
            child: Text(c.name[0], style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
          ),
          title: Text(c.name, textDirection: TextDirection.rtl),
          subtitle: Text(c.phone.isEmpty ? 'بدون هاتف' : c.phone),
          trailing: Text('${c.remainingDebt.toStringAsFixed(2)} دج',
              style: TextStyle(color: c.remainingDebt > 0 ? kDanger : kAccent, fontWeight: FontWeight.bold)),
          onTap: () {
            _searchCtrl.clear(); setState(() => _searchResults = []);
            Navigator.push(context, MaterialPageRoute(
                builder: (_) => CustomerDetailScreen(customerId: c.id!)));
          },
        )).toList(),
      ),
    );
  }

  Widget _buildStatsGrid() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 8),
      child: GridView.count(
        crossAxisCount: 2, shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
        childAspectRatio: 1.6, padding: const EdgeInsets.all(4),
        children: [
          _StatCard(Icons.warning_rounded, kDanger, '${_stats.remainingDebt.toStringAsFixed(0)} دج', 'الديون المتبقية'),
          _StatCard(Icons.check_circle, kAccent, '${_stats.totalPaid.toStringAsFixed(0)} دج', 'إجمالي المدفوع'),
          _StatCard(Icons.people, kPrimary, '${_stats.totalCustomers}', 'العملاء'),
          _StatCard(Icons.medication, kWarning, '${_stats.lowStockCount}', 'مخزون منخفض'),
        ],
      ),
    );
  }

  Widget _buildProgressCard() {
    return _Card(
      child: Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
        const Text('📊 نسبة التحصيل', style: TextStyle(fontWeight: FontWeight.bold, color: kPrimary, fontSize: 15)),
        const SizedBox(height: 10),
        Row(children: [
          Text('${_stats.paymentPercent}%',
              style: const TextStyle(fontWeight: FontWeight.bold, color: kPrimary, fontSize: 14)),
          const SizedBox(width: 8),
          Expanded(child: ClipRRect(
            borderRadius: BorderRadius.circular(6),
            child: LinearProgressIndicator(
              value: _stats.paymentPercent / 100,
              minHeight: 12,
              backgroundColor: const Color(0xFFE0E0E0),
              valueColor: const AlwaysStoppedAnimation(kAccent),
            ),
          )),
        ]),
        const SizedBox(height: 8),
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Text('متبقي: ${_stats.remainingDebt.toStringAsFixed(2)} دج',
              style: const TextStyle(color: kDanger, fontSize: 12)),
          Text('مدفوع: ${_stats.totalPaid.toStringAsFixed(2)} دج',
              style: const TextStyle(color: kAccent, fontSize: 12)),
        ]),
        const SizedBox(height: 4),
        Text('الإجمالي: ${_stats.totalDebt.toStringAsFixed(2)} دج',
            style: const TextStyle(color: kTextSec, fontSize: 12)),
      ]),
    );
  }

  Widget _buildDebtorsCard() {
    return _Card(
      child: Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
        const Text('⚠️ أكبر المديونين',
            style: TextStyle(fontWeight: FontWeight.bold, color: kPrimary, fontSize: 15)),
        const SizedBox(height: 8),
        if (_debtors.isEmpty)
          const Center(child: Text('🎉 لا توجد ديون حالياً', style: TextStyle(color: kTextSec)))
        else
          ..._debtors.asMap().entries.map((e) {
            final i = e.key; final c = e.value;
            final colors = [kDanger, kWarning, kAccent, kAccent, kAccent];
            return ListTile(
              dense: true,
              leading: CircleAvatar(
                backgroundColor: colors[i.clamp(0, 4)],
                radius: 14,
                child: Text('${i + 1}', style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.bold)),
              ),
              title: Text(c.name, textDirection: TextDirection.rtl, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
              subtitle: Text(c.phone.isEmpty ? 'بدون هاتف' : c.phone, style: const TextStyle(fontSize: 11)),
              trailing: Text('${c.remainingDebt.toStringAsFixed(2)} دج',
                  style: const TextStyle(color: kDanger, fontWeight: FontWeight.bold)),
              onTap: () => Navigator.push(context,
                  MaterialPageRoute(builder: (_) => CustomerDetailScreen(customerId: c.id!))),
            );
          }),
      ]),
    );
  }

  Widget _buildLowStockCard() {
    return _Card(
      borderColor: kWarning,
      child: Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
        const Text('🔴 مخزون منخفض',
            style: TextStyle(fontWeight: FontWeight.bold, color: kWarning, fontSize: 15)),
        const SizedBox(height: 8),
        ..._lowStock.map((m) => Padding(
          padding: const EdgeInsets.symmetric(vertical: 4),
          child: Row(children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
              decoration: BoxDecoration(
                color: m.isOutOfStock ? kDanger : kWarning,
                borderRadius: BorderRadius.circular(10),
              ),
              child: Text('${m.stock} ${m.unit}',
                  style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.bold)),
            ),
            const Spacer(),
            Text(m.name, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.bold)),
            const SizedBox(width: 6),
            Icon(Icons.warning_amber, size: 16, color: m.isOutOfStock ? kDanger : kWarning),
          ]),
        )),
      ]),
    );
  }

  Widget _buildQuickActions() {
    return _Card(
      child: Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
        const Text('⚡ إجراءات سريعة',
            style: TextStyle(fontWeight: FontWeight.bold, color: kPrimary, fontSize: 15)),
        const SizedBox(height: 10),
        Row(children: [
          Expanded(child: ElevatedButton.icon(
            icon: const Icon(Icons.person_add, size: 16),
            label: const Text('عميل جديد', style: TextStyle(fontSize: 12)),
            onPressed: () {},
            style: ElevatedButton.styleFrom(backgroundColor: kPrimary),
          )),
          const SizedBox(width: 8),
          Expanded(child: ElevatedButton.icon(
            icon: const Icon(Icons.add, size: 16),
            label: const Text('دواء جديد', style: TextStyle(fontSize: 12)),
            onPressed: () {},
            style: ElevatedButton.styleFrom(backgroundColor: kSecondary),
          )),
        ]),
      ]),
    );
  }
}

class _StatCard extends StatelessWidget {
  final IconData icon;
  final Color color;
  final String value;
  final String label;
  const _StatCard(this.icon, this.color, this.value, this.label);
  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.all(4),
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          border: Border(right: BorderSide(color: color, width: 4)),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
          Icon(icon, color: color, size: 22),
          const Spacer(),
          Text(value, style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: color)),
          const SizedBox(height: 2),
          Text(label, style: const TextStyle(fontSize: 10, color: kTextSec), textAlign: TextAlign.right),
        ]),
      ),
    );
  }
}

class _Card extends StatelessWidget {
  final Widget child;
  final Color? borderColor;
  const _Card({required this.child, this.borderColor});
  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: borderColor != null ? Border.all(color: borderColor!) : null,
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.06), blurRadius: 4, offset: const Offset(0, 2))],
      ),
      child: child,
    );
  }
}
